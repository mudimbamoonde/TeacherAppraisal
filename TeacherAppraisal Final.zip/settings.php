<?php include "includes/hearder.php"; ?>
<!-- Start top-course Area -->

<section class="top-course-area section-gap">
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="menu-content pb-60 col-lg-9">
                <div class="title text-center">

                    <h1 class="mb-10">Configuration Panel</h1>
                    <hr>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="single-top-course">
                    <div class="thumbs relative">
                        <div class="overlay overlay-bg"></div>
                        <img class="img-fluid" src="img/pages/tc1.jpg" alt="">
                        <a class="thumb-btn" href="question_ln.php">Evaluation Variables/Marks</a>
                    </div>

                </div>
            </div>
<!--            <div class="col-lg-4 col-md-6">-->
<!--                <div class="single-top-course">-->
<!--                    <div class="thumbs relative">-->
<!--                        <div class="overlay overlay-bg"></div>-->
<!--                        <img class="img-fluid" src="img/pages/tc2.jpg" alt="">-->
<!--                        <a class="thumb-btn" href="#">Learners Evaluation</a>-->
<!--                    </div>-->
<!---->
<!--                </div>-->
<!--            </div>-->

            <div class="col-lg-4 col-md-6">
                <div class="single-top-course">
                    <div class="thumbs relative">
                        <div class="overlay overlay-bg"></div>
                        <img class="img-fluid" src="img/pages/tc4.jpg" alt="">
                        <a class="thumb-btn" href="question_dp.php">HOD Questions /Variables</a>
                    </div>

                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="single-top-course">
                    <div class="thumbs relative">
                        <div class="overlay overlay-bg"></div>
                        <img class="img-fluid" src="img/pages/tc3.jpg" alt="">
                        <a class="thumb-btn" href="cate.php">HOD Categories</a>
                    </div>

                </div>
            </div>

        </div>
</section>
<!-- End top-course Area -->

<!-- start footer Area -->

<?php include "includes/footer.php"; ?>
<!-- End footer Area -->




